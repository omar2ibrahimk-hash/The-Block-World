
import * as THREE from 'three';
import {PointerLockControls} from 'three/examples/jsm/controls/PointerLockControls.js';
import './style.css';

const app=document.querySelector('#app');
app.innerHTML=`<div id="hud">
<div class="top">🌎 <b>BlockWorld</b> · <span id="mode">Survival</span><br><small>WASD move · Space jump · LMB mine · RMB place · E inventory · Esc menu</small></div>
<div class="stats">❤️ <div class="bar"><div id="hp" class="fill hp"></div></div>🍗 <div class="bar"><div id="food" class="fill food"></div></div>⚡ <div class="bar"><div id="stam" class="fill stam"></div></div></div>
<div id="cross"></div><div id="notice"></div><div id="hotbar"></div>
<div id="mobile"><button class="m left">◀</button><button class="m right">▶</button><button class="m up">▲</button><button class="m mine">⛏</button><button class="m place">＋</button><button class="m jump">↥</button></div>
<div id="menu"><div class="panel"><h1>BlockWorld</h1><p>Explore, build, craft, survive and discover a procedural voxel world.</p>
<button id="start">Play</button><button id="creative">Creative Mode</button><button id="save">Save World</button><button id="load">Load World</button>
<p><small>This is an original voxel sandbox game. It uses no Minecraft assets.</small></p></div></div></div>`;

const scene=new THREE.Scene(); scene.background=new THREE.Color(0x8bc9ef); scene.fog=new THREE.Fog(0x8bc9ef,35,105);
const camera=new THREE.PerspectiveCamera(75,innerWidth/innerHeight,.1,180); camera.position.set(0,10,8);
const renderer=new THREE.WebGLRenderer({antialias:true}); renderer.setPixelRatio(Math.min(devicePixelRatio,1.7)); renderer.setSize(innerWidth,innerHeight); renderer.shadowMap.enabled=true; document.body.prepend(renderer.domElement);
const hemi=new THREE.HemisphereLight(0xbfe7ff,0x35402d,1.25); scene.add(hemi);
const sun=new THREE.DirectionalLight(0xffffff,1.6); sun.position.set(40,70,25); sun.castShadow=true; sun.shadow.mapSize.set(1024,1024); scene.add(sun);
const controls=new PointerLockControls(camera,document.body); scene.add(camera);

const defs={
 grass:{c:0x55a844,solid:true},dirt:{c:0x8a5a35,solid:true},stone:{c:0x777b80,solid:true},sand:{c:0xd6c17a,solid:true},
 snow:{c:0xe8f2f5,solid:true},wood:{c:0x79502f,solid:true},leaves:{c:0x2f8d48,solid:true},planks:{c:0xb27b43,solid:true},
 glass:{c:0x91dce8,solid:true,transparent:true},brick:{c:0x9b5040,solid:true},torch:{c:0xffa32b,solid:false},
 coal:{c:0x25272a,solid:true},iron:{c:0xb8a99a,solid:true},gold:{c:0xe2c044,solid:true},water:{c:0x3d9ed8,solid:false,transparent:true}
};
const names=Object.keys(defs).filter(k=>defs[k].solid); let selected=0;
const world=new Map(), meshes=new Map(); const CH=16, R=5;
function key(x,y,z){return `${x},${y},${z}`}
function hash(x,z){let n=Math.sin(x*127.1+z*311.7)*43758.5453;return n-Math.floor(n)}
function height(x,z){
 let h=6+Math.floor(Math.sin(x*.075)*2+Math.cos(z*.09)*2+Math.sin((x+z)*.025)*3);
 const d=Math.hypot(x,z); if(d>58) h=Math.max(2,h-Math.floor((d-58)/7)); return Math.max(2,Math.min(14,h));
}
function biome(x,z){const n=hash(Math.floor(x/24),Math.floor(z/24)); if(n<.18)return'snow';if(n<.36)return'sand';return'grass'}
function setBlock(x,y,z,t){if(y<0||y>40)return;world.set(key(x,y,z),t)}
function getBlock(x,y,z){return world.get(key(x,y,z))}
function generate(){
 for(let cx=-R;cx<=R;cx++)for(let cz=-R;cz<=R;cz++){
  for(let x=cx*CH;x<(cx+1)*CH;x++)for(let z=cz*CH;z<(cz+1)*CH;z++){
   const h=height(x,z), b=biome(x,z); for(let y=0;y<=h;y++)setBlock(x,y,z,y===h?b:y>h-3?'dirt':'stone');
   if(b==='sand'&&h<5)for(let y=h+1;y<6;y++)setBlock(x,y,z,'water');
   if(b==='grass'&&hash(x*2,z*2)>.91&&h>5){
    for(let y=h+1;y<h+5;y++)setBlock(x,y,z,'wood');
    for(let dx=-2;dx<=2;dx++)for(let dz=-2;dz<=2;dz++)for(let dy=3;dy<=5;dy++)if(Math.abs(dx)+Math.abs(dz)+dy<8)setBlock(x+dx,h+dy,z+dz,'leaves');
   }
  }
 }
}
function material(t){let d=defs[t],m=new THREE.MeshStandardMaterial({color:d.c,transparent:!!d.transparent,opacity:d.transparent?.62:1,roughness:.85});return m}
const geo=new THREE.BoxGeometry(1,1,1);
function rebuild(){
 for(const m of meshes.values())scene.remove(m);meshes.clear();
 const buckets={}; for(const [k,t] of world){if(!buckets[t])buckets[t]=[];buckets[t].push(k)}
 for(const t in buckets){
  const group=new THREE.Group(); group.userData.type=t;
  for(const k of buckets[t]){const [x,y,z]=k.split(',').map(Number),m=new THREE.Mesh(geo,material(t));m.position.set(x+.5,y+.5,z+.5);m.castShadow=t!=='water';m.receiveShadow=true;m.userData.key=k;group.add(m)}
  scene.add(group);meshes.set(t,group)
 }
}
generate();rebuild();

const keys={}; addEventListener('keydown',e=>{keys[e.code]=true;if(e.code==='Escape')document.querySelector('#menu').classList.remove('hidden');if(e.code==='KeyE')document.querySelector('#menu').classList.remove('hidden');if(/^Digit[1-9]$/.test(e.code))selected=+e.code.slice(5)-1;});
addEventListener('keyup',e=>keys[e.code]=false);
let vel=new THREE.Vector3(),onGround=false,mode='Survival',hpv=100,food=100,stam=100;
const ray=new THREE.Raycaster();
function target(){ray.setFromCamera(new THREE.Vector2(0,0),camera);const a=ray.intersectObjects([...meshes.values()].flatMap(g=>g.children),false);return a[0]}
function mine(){const h=target();if(!h)return;const p=h.object.userData.key;world.delete(p);rebuild();notice('Block mined')}
function place(){const h=target();if(!h)return;const n=h.face.normal.clone();const p=h.object.position.clone().add(n);const x=Math.floor(p.x),y=Math.floor(p.y),z=Math.floor(p.z);if(!getBlock(x,y,z)){world.set(key(x,y,z),names[selected]);rebuild();notice('Block placed')}}
function notice(s){const n=document.querySelector('#notice');n.textContent=s;n.style.opacity=1;clearTimeout(notice.t);notice.t=setTimeout(()=>n.style.opacity=0,900)}
addEventListener('mousedown',e=>{if(e.button===0){if(controls.isLocked)mine();else controls.lock()} if(e.button===2)place()});addEventListener('contextmenu',e=>e.preventDefault());

function updateHUD(){document.querySelector('#hp').style.width=hpv+'%';document.querySelector('#food').style.width=food+'%';document.querySelector('#stam').style.width=stam+'%';document.querySelector('#mode').textContent=mode;document.querySelector('#hotbar').innerHTML=names.slice(0,9).map((n,i)=>`<div class="slot ${i===selected?'sel':''}" data-i="${i}"><div class="swatch" style="background:#${defs[n].c.toString(16).padStart(6,'0')}"></div><small>${i+1}</small></div>`).join('');document.querySelectorAll('.slot').forEach(s=>s.onclick=()=>{selected=+s.dataset.i;updateHUD()})}
updateHUD();

function save(){localStorage.setItem('blockworld-save',JSON.stringify([...world]));localStorage.setItem('blockworld-player',JSON.stringify({x:camera.position.x,y:camera.position.y,z:camera.position.z,mode}));notice('World saved')}
function load(){const w=localStorage.getItem('blockworld-save');if(!w){notice('No save found');return}world.clear();for(const [k,v] of JSON.parse(w))world.set(k,v);const p=JSON.parse(localStorage.getItem('blockworld-player')||'{}');if(p.x!=null)camera.position.set(p.x,p.y,p.z);mode=p.mode||'Survival';rebuild();updateHUD();notice('World loaded')}
document.querySelector('#start').onclick=()=>{document.querySelector('#menu').classList.add('hidden');controls.lock()};
document.querySelector('#creative').onclick=()=>{mode=mode==='Creative'?'Survival':'Creative';updateHUD();document.querySelector('#menu').classList.add('hidden');controls.lock();notice(mode+' mode')};
document.querySelector('#save').onclick=save;document.querySelector('#load').onclick=load;
setInterval(save,30000);

let last=performance.now(),day=0;
function animate(now){requestAnimationFrame(animate);let dt=Math.min(.05,(now-last)/1000);last=now;day+=dt*.002;
 const sprint=keys.ShiftLeft||keys.ShiftRight;let speed=mode==='Creative'?9:5;if(sprint&&stam>1){speed=8;stam=Math.max(0,stam-dt*18)}else stam=Math.min(100,stam+dt*10);
 let dir=new THREE.Vector3((keys.KeyD?1:0)-(keys.KeyA?1:0),0,(keys.KeyS?1:0)-(keys.KeyW?1:0));if(dir.lengthSq())dir.normalize();camera.getWorldDirection(new THREE.Vector3());const forward=new THREE.Vector3();camera.getWorldDirection(forward);forward.y=0;forward.normalize();const right=new THREE.Vector3().crossVectors(forward,new THREE.Vector3(0,1,0)).normalize();vel.x=(right.x*dir.x+forward.x*dir.z)*speed;vel.z=(right.z*dir.x+forward.z*dir.z)*speed;
 if(mode!=='Creative'){vel.y-=22*dt;if(keys.Space&&onGround){vel.y=8;onGround=false}camera.position.y+=vel.y*dt;if(camera.position.y<height(Math.floor(camera.position.x),Math.floor(camera.position.z))+1.7){camera.position.y=height(Math.floor(camera.position.x),Math.floor(camera.position.z))+1.7;vel.y=0;onGround=true}food=Math.max(0,food-dt*(sprint?.45:.12));if(food===0)hpv=Math.max(0,hpv-dt*1)}else{if(keys.Space)vel.y=8;else if(keys.ControlLeft)vel.y=-8;camera.position.y+=vel.y*dt;vel.y*=.8}
 camera.position.x+=vel.x*dt;camera.position.z+=vel.z*dt;
 sun.position.x=Math.cos(day)*70;sun.position.z=Math.sin(day)*70;sun.position.y=50+Math.sin(day)*30;sun.intensity=.65+.9*Math.max(0,Math.sin(day));
 renderer.render(scene,camera);updateHUD();
}
animate(performance.now());
addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight)});

document.querySelectorAll('.m').forEach(b=>b.addEventListener('touchstart',e=>{e.preventDefault();const c=b.className;if(c.includes('left'))keys.KeyA=true;if(c.includes('right'))keys.KeyD=true;if(c.includes('up'))keys.KeyW=true;if(c.includes('jump'))keys.Space=true;if(c.includes('mine'))mine();if(c.includes('place'))place()}));
document.querySelectorAll('.m').forEach(b=>b.addEventListener('touchend',()=>{keys.KeyA=keys.KeyD=keys.KeyW=keys.Space=false}));
